
/* This file was generated automatically by Zephir do not modify it! */

#ifndef ZEPHIR_CLASS_ENTRIES_H
#define ZEPHIR_CLASS_ENTRIES_H

#include "pocketmine/level/generator/noise/generator.zep.h"
#include "pocketmine/math/axisalignedbb.zep.h"
#include "pocketmine/math/vector2.zep.h"
#include "pocketmine/math/vector3.zep.h"
#include "pocketmine/utils/binary.zep.h"
#include "pocketmine/utils/random.zep.h"

#endif