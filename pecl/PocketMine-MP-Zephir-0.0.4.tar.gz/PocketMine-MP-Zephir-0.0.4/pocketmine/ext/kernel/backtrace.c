void zephir_print_backtrace(void){}
