# PocketMine-MP C PHP extension


Optional extension that implements parts of PocketMine-MP in a fast PHP extension
