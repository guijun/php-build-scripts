
/* This file was generated automatically by Zephir do not modify it! */

#ifndef ZEPHIR_CLASS_ENTRIES_H
#define ZEPHIR_CLASS_ENTRIES_H

#include "pocketmine/level/generator/noise/generator.h"
#include "pocketmine/math/axisalignedbb.h"
#include "pocketmine/math/vector2.h"
#include "pocketmine/math/vector3.h"
#include "pocketmine/utils/binary.h"
#include "pocketmine/utils/random.h"

#endif